define({
	popupTriggerLabel: 'Afișarea sau ascunderea coloanelor',
	popupLabel: 'Afișarea sau ascunderea coloanelor'
});
define({
	dgridUrl: 'http://dgrid.io',
	docBaseUrl: 'https://github.com/SitePen/dgrid/blob/dev-1.0/doc/'
});

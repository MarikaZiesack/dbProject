//>>built
define("dijit/form/VerticalRule",["dojo/_base/declare","./HorizontalRule"],function(_1,_2){
return _1("dijit.form.VerticalRule",_2,{templateString:"<div class=\"dijitRuleContainer dijitRuleContainerV\"></div>",_positionPrefix:"<div class=\"dijitRuleMark dijitRuleMarkV\" style=\"top:",_isHorizontal:false});
});

//>>built
define("dijit/form/nls/ja/Textarea",({iframeEditTitle:"編集域",iframeFocusTitle:"編集域フレーム"}));

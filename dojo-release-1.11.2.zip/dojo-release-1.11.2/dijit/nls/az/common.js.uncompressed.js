define(
"dijit/nls/az/common", ({
	"buttonOk" : "Ok",
	"buttonCancel" : "Ləğv et",
	"buttonSave" : "Saxla",
	"itemClose" : "Bağla"
})
);
